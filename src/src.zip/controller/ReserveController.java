package controller;

import java.sql.Timestamp;
import java.util.HashMap;

import model.dao.MovieDAO;
import model.dao.ReserveDAO;
import model.dao.ScheduleDAO;
import model.dao.TheaterDAO;
import model.dto.MovieDTO;
import model.dto.ScheduleDTO;
import model.dto.TheaterDTO;

public class ReserveController {

	public HashMap<String, Object> getReserveDetail(int scheduleId) {
		ScheduleDAO sdao = new ScheduleDAO();
		MovieDAO mdao = new MovieDAO();
		TheaterDAO tdao = new TheaterDAO();
		ScheduleDTO schedule = sdao.getScheduleById(scheduleId);
		MovieDTO movie = mdao.getMovieById(schedule.getMovieID());
		TheaterDTO theater = tdao.getTheaterById(schedule.getTheaterId());
		
		Timestamp startTime = schedule.getStartTime();
		String movieName = movie.getMovieName();
		String theaterName = theater.getTheaterName();
		HashMap<String, Object> reserveDetail = new HashMap<>();
		reserveDetail.put("startTime", startTime);
		reserveDetail.put("movieName", movieName);
		reserveDetail.put("theaterName", theaterName);
		return reserveDetail;
	}

	public boolean cancelReserve(int reserveId) {
		ReserveDAO rdao = new ReserveDAO();
		return rdao.deleteReserveByReserveId(reserveId);
		
	}

}
