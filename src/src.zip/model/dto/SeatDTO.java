package model.dto;

public class SeatDTO {

}
