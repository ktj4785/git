package model.dto;

public class ActorDTO {

}
