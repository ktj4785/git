package model.dao;

public class ReviewDAO {

}
