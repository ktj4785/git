package model.dao;

public class SeatDAO {

}
