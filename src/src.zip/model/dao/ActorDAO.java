package model.dao;

public class ActorDAO {

}
