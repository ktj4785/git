package view;

public class ScheduleView {
	public ScheduleView() {
		
	}
}
