package view;

public class MovieSearchView {
	public MovieSearchView() {
		
	}
}