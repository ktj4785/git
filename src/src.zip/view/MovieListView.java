package view;

public class MovieListView {
	public MovieListView() {
		
	}
}
