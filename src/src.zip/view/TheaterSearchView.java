package view;

public class TheaterSearchView {
	public TheaterSearchView() {
		
	}
}
