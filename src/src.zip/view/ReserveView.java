package view;

public class ReserveView {
	public ReserveView() {
		
	}
}